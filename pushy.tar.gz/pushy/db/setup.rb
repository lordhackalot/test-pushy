require 'sequel'
require 'yaml'
require_relative 'ios_table'
require_relative 'android_table'

DB = Sequel.connect(ENV['DATABASE_URL'])

YAML.load_file('config/games.yml').each do |platform, games|
  games.each do |game|
    send "create_table_#{platform}_appsflyer", "#{game}_push_#{platform}".to_sym
  end
end
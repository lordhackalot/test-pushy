require 'sequel'
puts 'connect db'
$db = Sequel.connect(ENV.fetch 'DATABASE_URL', :max_connections => 10)
puts 'connect db complete'
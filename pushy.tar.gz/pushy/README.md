Pushy
--------------

![pusheen](http://24.media.tumblr.com/tumblr_lxq4dq4Lrl1qhy6c9o4_250.gif)

Pushy is an API server providing endpoints for 3rd party services to push data to us.

Right now it's only used for AppsFlyer.

It just saves the data it receives into a Postgres database.

# Environment variables
`DATABASE_URL` - connection string for Postgres

# Diagram
![Analytics Callback](https://github.com/pocket-playlab/assets/blob/master/assets/backend/AnalyticsCallback/pl-analytics-callback.png?raw=true)

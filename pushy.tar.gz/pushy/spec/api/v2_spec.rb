require 'spec_helper'

describe "v2" do

  def app
    Sinatra::Application
  end

  let(:dsn) { 'sqlite://test.db' }
  let(:table_ios) { 'rr_push_ios' }
  let(:table_android) { 'rr_push_android' }
  let(:run_date) { Date.today }
  let(:db) { Sequel.connect(dsn) }

  require File.expand_path '../../../app/main.rb', __FILE__

  context 'callback' do

    let(:body) do
      {
        :fb_adgroup_id => "",
        :device_type => "iPhone5S",
        :click_time => "2015-05-26 06:47:35",
        :agency => "",
        :ip => "27.55.28.78",
        :cost_per_install => "",
        :fb_campaign_id => "",
        :is_retargeting => 'f',
        :re_targeting_conversion_type => "",
        :city => "Huai Khwang",
        :af_sub1 => "",
        :af_sub2 => "d",
        :event_value => "",
        :af_sub3 => "",
        :fb_adset_name => "",
        :af_sub4 => "",
        :customer_user_id => "",
        :mac => "",
        :af_sub5 => "",
        :campaign => "60621013047",
        :event_name => "",
        :currency => "",
        :install_time => "2015-05-26 08:53:36",
        :fb_adgroup_name => "",
        :event_time => "2015-05-26 08:53:36",
        :platform => "ios",
        :sdk_version => "v2.5.3.14",
        :appsflyer_device_id => "1432648072000-8318042",
        :device_name => "Administrator’s iPhone",
        :wifi => 'f',
        :media_source => "googleadwords_int",
        :country_code => "TH",
        :idfa => "865315C9-6E59-4A16-912B-F0C042CCC658",
        :fb_campaign_name => "",
        :click_url => "",
        :language => "th",
        :app_id => "id855124397",
        :app_version => "1.0.22.4",
        :attribution_type => "regular",
        :af_siteid => "mobileapp::1-920692946",
        :os_version => "8.3",
        :fb_adset_id => "",
        :event_type => "install",
        :idfv => "243212FA-91B0-45E3-89D2-709B3EDDD88A",
        :http_referrer => ""
      }.to_json
    end

    context 'wrong url' do
      it 'should return 404 status when url not found' do
        post 'v2/wrong-url'
        last_response.status.should == 404
      end

      it 'should return 404 status when method is incorrect' do
        get 'v2/ios/rr'
        last_response.status.should == 404
      end
    end

    context "incorrect ip" do
      it 'should return status 401' do
        post 'v2/ios/rr', {}, { 'REMOTE_ADDR' => '1.2.3.4' }
        last_response.status.should == 401
      end
    end

    context "correct ip" do
      before :each do
        db[:rr_push_ios].truncate
        post '/v2/ios/rr', body, { 'REMOTE_ADDR' => '54.195.225.209' }
      end

      it 'should return status 200' do
        last_response.status.should == 200
      end

      it 'contains data from appsflyer' do
        db[table_ios].count.should == 1
      end
    end
  end

  context 'AppsFlyer android for push api' do
    let(:body_android) do
    {
      :device_model => "SS",
      :fb_adgroup_id => "",
      :operator => "AIS",
      :click_time => "",
      :agency => "",
      :ip => "111.222.33.444",
      :cost_per_install => "",
      :fb_campaign_id => "",
      :imei => "1122334455",
      :is_retargeting => 'f',
      :re_targeting_conversion_type => "",
      :android_id => "a123b3d4b5ocdcd",
      :city => "None",
      :af_sub1 => "",
      :af_sub2 => "",
      :event_value => "0",
      :af_sub3 => "",
      :fb_adset_name => "",
      :af_sub4 => "",
      :customer_user_id => "",
      :mac => "",
      :af_sub5 => "",
      :campaign => "",
      :event_name => "User Open IAP Store",
      :currency => "",
      :install_time => "2015-05-26 09:06:17",
      :fb_adgroup_name => "",
      :event_time => "2015-05-26 09:06:15",
      :platform => "android",
      :sdk_version => "1.17",
      :appsflyer_device_id => "APPSFLYER-DEVICE-ID",
      :wifi => 't',
      :advertising_id => "ADVERTISING-ID",
      :media_source => "",
      :country_code => "TH",
      :fb_campaign_name => "",
      :click_url => "",
      :carrier => "AIS",
      :language => "English",
      :app_id => "app.id",
      :app_version => "1.0.22.4",
      :attribution_type => "organic",
      :af_siteid => "",
      :os_version => "5.0.1",
      :fb_adset_id => "",
      :device_brand => "samsung",
      :event_type => "in-app-event",
      :http_referrer => ""
    }.to_json
    end

    before :each do
      db[:rr_push_android].truncate
      post 'v2/android/rr', body_android, { 'REMOTE_ADDR' => '54.195.225.209' }
    end

    it 'returns status 200' do
      last_response.status.should == 200
    end

    it 'inserts only the columns that database have' do
      db[table_android].count.should == 1
      keys_path = "config/appsflyer_pg_android_keys.yml"
      keys_name = YAML.load_file(keys_path)
      db["select * from #{table_android}"].first.keys.should =~ keys_name['keys']
    end
  end

  context 'AppsFlyer add new field for push api' do
    let(:body_ios) do
      {
        :fb_adgroup_id => "",
        :device_type => "iPhone 5s",
        :click_time => "2015-05-26 06:47:35",
        :agency => "",
        :ip => "11.22.33.44",
        :cost_per_install => "",
        :fb_campaign_id => "",
        :is_retargeting => 'f',
        :re_targeting_conversion_type => "",
        :city => "Huai Khwang",
        :af_sub1 => "",
        :af_sub2 => "d",
        :event_value => "",
        :af_sub3 => "",
        :fb_adset_name => "",
        :af_sub4 => "",
        :customer_user_id => "",
        :mac => "",
        :af_sub5 => "",
        :campaign => "60621013047",
        :event_name => "",
        :currency => "",
        :install_time => "2015-05-26 08:53:36",
        :fb_adgroup_name => "",
        :event_time => "2015-05-26 08:53:36",
        :platform => "ios",
        :sdk_version => "v2.5.3.14",
        :appsflyer_device_id => "1432648072000-8318042",
        :device_name => "Administrator’s iPhone",
        :wifi => 'f',
        :media_source => "googleadwords_int",
        :country_code => "TH",
        :idfa => "IIII-DDDD-FFFF-AAAA",
        :fb_campaign_name => "",
        :click_url => "",
        :language => "th",
        :app_id => "id855124397",
        :app_version => "1.0.22.4",
        :attribution_type => "regular",
        :af_siteid => "mobileapp::1-920692946",
        :os_version => "8.3",
        :fb_adset_id => "",
        :event_type => "install",
        :idfv => "III-DDD-FFF-VVV",
        :http_referrer => "",
        :new_column => 'new_value'
      }.to_json
    end

    before :each do
      db[:rr_push_ios].truncate
      post 'v2/ios/rr', body_ios, { 'REMOTE_ADDR' => '54.195.225.209' }
    end

    it 'returns status 200' do
      last_response.status.should == 200
    end

    it 'inserts only the columns that database have' do
      db[table_ios].count.should == 1
      keys_path = "config/appsflyer_pg_ios_keys.yml"
      keys_name = YAML.load_file(keys_path)
      db["select * from #{table_ios}"].first.keys.should =~ keys_name['keys']
    end

  end

end

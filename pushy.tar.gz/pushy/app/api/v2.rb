games = YAML.load_file('config/games.yml')

games.each do |platform, games|
  games.each do |game|

    send 'post', "/v2/#{platform}/#{game}" do
      appsflyer_callback("#{game}_push_#{platform}".to_sym, request)
    end

  end
end
def appsflyer_callback(table_name, request)
  puts "request ip is #{request.ip}"

  if ip_filter(request.ip, :appsflyer)
    response_data = JSON.parse request.body.read
    insert_data(table_name, response_data.merge( 'RunDate' => Date.today ))
    respond 200, 'insert complete'
  else
    respond 401, 'incorrect ip'
  end
end

def ip_filter(request_ip, source_name)
  if source_name == :appsflyer
    accept_ip = YAML.load_file('config/appsflyer_accept_ip.yml')
    return true if accept_ip['ip'].include? request_ip
  end
  false
end

def respond(status, message)
  [
    status,
    { 'Content-Type' => 'text/plain' },
    "#{message}\n"
  ]
end

def insert_data(table_name, data)
  puts "table name: #{table_name}"
  filter_data = key_filter(data)
  table = $db[table_name]
  puts "inserting data"
  table.insert(filter_data)
  puts "inserted"
end

def key_filter(data)
  keys_path = "config/appsflyer_pg_#{data['platform']}_keys.yml"
  keys_name = YAML.load_file(keys_path)
  data.each_with_object({}) do |row, data_to_insert|
    if keys_name['keys'].include? row[0].to_sym
      data_to_insert[row[0]] = row[1]
    else
      p "key: #{row[0]} not found on database"
      p "value: #{data}"
    end
  end
end
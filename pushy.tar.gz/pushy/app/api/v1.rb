post '/ranchrun-callback' do
  appsflyer_callback(:rr_push_ios, request)
end

post '/ranchrun-android-callback' do
  appsflyer_callback(:rr_push_android, request)
end

post '/jewelcubes-ios-callback' do
  appsflyer_callback(:jewelcubes_push_ios, request)
end

post '/jewelcubes-android-callback' do
  appsflyer_callback(:jewelcubes_push_android, request)
end

post '/junglecubes-ios-callback' do
  appsflyer_callback(:junglecubes_push_ios, request)
end

post '/junglecubes-android-callback' do
  appsflyer_callback(:junglecubes_push_android, request)
end

post '/dragoncubes-ios-callback' do
  appsflyer_callback(:dragoncubes_push_ios, request)
end

post '/dragoncubes-android-callback' do
  appsflyer_callback(:dragoncubes_push_android, request)
end

post '/bubblecubes-android-callback' do
  appsflyer_callback(:bubblecubes_push_android, request)
end

post '/farmcubes-android-callback' do
  appsflyer_callback(:farmcubes_push_android, request)
end
require 'json'
require 'sinatra'
require 'yaml'

require_relative '../config/sequel'

get '/status' do
  content_type :json
  { message: 'OK' }.to_json
end

require_relative 'persistence'
require_relative 'api/v1'
require_relative 'api/v2'



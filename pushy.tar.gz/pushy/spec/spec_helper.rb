require 'rspec'
require 'sinatra'
require 'webmock/rspec'
require 'rack/test'
require 'sequel'
require 'sqlite3'
require 'yaml'
require 'supports/ranchrun_table_setup'

RSpec.configure do |config|
  config.mock_with :rspec
  config.include Rack::Test::Methods

  config.expect_with :rspec do |c|
    c.syntax = :should
  end

  WebMock.disable_net_connect!(allow_localhost: true)
end


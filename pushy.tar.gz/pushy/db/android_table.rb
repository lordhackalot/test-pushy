def create_table_android_appsflyer(table_name)
  if not DB.table_exists?(table_name)
    DB.create_table table_name do
      primary_key :id
      Date :RunDate
      String :device_model
      String :fb_adgroup_id
      String :operator
      String :click_time
      String :agency
      String :ip
      String :cost_per_install
      String :fb_campaign_id
      String :imei
      Boolean :is_retargeting
      String :re_targeting_conversion_type
      String :android_id
      String :city
      String :af_sub1
      String :af_sub2
      String :event_value
      String :af_sub3
      String :fb_adset_name
      String :af_sub4
      String :customer_user_id
      String :mac
      String :af_sub5
      String :campaign
      String :event_name
      String :currency
      String :install_time
      String :fb_adgroup_name
      String :event_time
      String :platform
      String :sdk_version
      String :appsflyer_device_id
      Boolean :wifi
      String :advertising_id
      String :media_source
      String :country_code
      String :fb_campaign_name
      String :click_url
      String :carrier
      String :language
      String :app_id
      String :app_version
      String :attribution_type
      String :af_siteid
      String :os_version
      String :fb_adset_id
      String :device_brand
      String :event_type
      String :http_referrer
    end
  end
end
